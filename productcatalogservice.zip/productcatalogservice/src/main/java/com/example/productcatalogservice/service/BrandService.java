package com.example.productcatalogservice.service;

import java.util.List;

import com.example.productcatalogservice.model.Brand;

public interface BrandService {
	
	List<Brand> findAll();
		

}
